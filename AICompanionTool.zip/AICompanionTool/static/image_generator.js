document.addEventListener('DOMContentLoaded', function() {
    const imageForm = document.getElementById('image-form');
    const resultContainer = document.getElementById('result-container');
    const imageResult = document.getElementById('image-result');
    const imageContainer = document.getElementById('image-container');
    const imagePrompt = document.getElementById('image-prompt');
    const downloadLink = document.getElementById('download-link');
    const errorContainer = document.getElementById('error-container');
    const errorMessage = document.getElementById('error-message');
    const loading = document.getElementById('loading');
    
    imageForm.addEventListener('submit', async function(e) {
        e.preventDefault();
        
        const prompt = document.getElementById('prompt').value.trim();
        const width = document.getElementById('width').value;
        const height = document.getElementById('height').value;
        
        // Input validation
        if (!prompt) {
            showError('Please enter an image description before submitting.');
            return;
        }
        
        // Show loading indicator
        showLoading();
        hideError();
        
        // Send request to the server
        try {
            const response = await fetch('/api/text-to-image', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    prompt: prompt,
                    width: parseInt(width),
                    height: parseInt(height)
                })
            });
            
            const data = await response.json();
            
            hideLoading();
            
            if (data.success) {
                showImageResult(data.url, prompt);
            } else {
                showError(data.error || 'An unknown error occurred.');
            }
        } catch (error) {
            hideLoading();
            showError('Failed to communicate with the server. Please try again.');
            console.error('Error:', error);
        }
    });
    
    function showImageResult(imageUrl, promptText) {
        // Clear previous image if any
        imageContainer.innerHTML = '';
        
        // Create the image element
        const img = document.createElement('img');
        img.src = imageUrl;
        img.className = 'max-w-full h-auto rounded-md shadow-sm';
        img.alt = 'Generated image';
        imageContainer.appendChild(img);
        
        // Update prompt display
        imagePrompt.textContent = `Prompt: "${promptText}"`;
        
        // Update download link
        downloadLink.href = imageUrl;
        downloadLink.download = 'generated-image.png';
        
        // Show the result
        imageResult.classList.remove('hidden');
        resultContainer.classList.remove('hidden');
        resultContainer.scrollIntoView({ behavior: 'smooth' });
    }
    
    function showError(text) {
        errorMessage.textContent = text;
        errorContainer.classList.remove('hidden');
        errorContainer.scrollIntoView({ behavior: 'smooth' });
    }
    
    function hideError() {
        errorContainer.classList.add('hidden');
    }
    
    function showLoading() {
        loading.classList.remove('hidden');
        imageResult.classList.add('hidden');
        resultContainer.classList.remove('hidden');
    }
    
    function hideLoading() {
        loading.classList.add('hidden');
    }
});
