document.addEventListener('DOMContentLoaded', function() {
    const videoForm = document.getElementById('video-form');
    const textInput = document.getElementById('text');
    const durationInput = document.getElementById('duration');
    const resultContainer = document.getElementById('result-container');
    const loadingDiv = document.getElementById('loading');
    const videoResult = document.getElementById('video-result');
    const videoContainer = document.getElementById('video-container');
    const audioContainer = document.getElementById('audio-container');
    const videoText = document.getElementById('video-text');
    const downloadLink = document.getElementById('download-link');
    const errorContainer = document.getElementById('error-container');
    const errorMessage = document.getElementById('error-message');

    // Function to show loading state
    function showLoading() {
        resultContainer.classList.remove('hidden');
        loadingDiv.classList.remove('hidden');
        videoResult.classList.add('hidden');
        errorContainer.classList.add('hidden');
    }

    // Function to hide loading state
    function hideLoading() {
        loadingDiv.classList.add('hidden');
    }

    // Function to display error
    function showError(message) {
        errorContainer.classList.remove('hidden');
        errorMessage.textContent = message;
        resultContainer.classList.add('hidden');
    }

    // Function to display animation and audio result
    function showVideoResult(videoUrl, audioUrl, text) {
        hideLoading();
        videoResult.classList.remove('hidden');
        
        // Create image element for the animated GIF
        videoContainer.innerHTML = `
            <img src="${videoUrl}" alt="Animated visualization" class="w-full max-w-md border border-gray-300 rounded-md">
        `;
        
        // Create audio element if available
        if (audioUrl) {
            audioContainer.innerHTML = `
                <div class="bg-gray-100 p-3 rounded-md w-full max-w-md">
                    <p class="text-sm text-gray-700 mb-2">Audio Narration:</p>
                    <audio controls class="w-full">
                        <source src="${audioUrl}" type="audio/mpeg">
                        Your browser does not support the audio element.
                    </audio>
                </div>
            `;
        } else {
            audioContainer.innerHTML = '';
        }
        
        // Set text display
        videoText.textContent = text;
        
        // Set download link for the GIF
        downloadLink.href = videoUrl;
        downloadLink.download = 'animation_' + new Date().getTime() + '.gif';
    }

    // Handle form submission
    videoForm.addEventListener('submit', function(e) {
        e.preventDefault();
        
        const text = textInput.value.trim();
        const duration = parseInt(durationInput.value);
        
        if (!text) {
            showError('Please enter some text for the animation.');
            return;
        }
        
        if (isNaN(duration) || duration < 5 || duration > 60) {
            showError('Please enter a valid duration between 5 and 60 seconds.');
            return;
        }
        
        showLoading();
        
        // Send request to server
        fetch('/api/text-to-video', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                text: text,
                duration: duration
            }),
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                showVideoResult(data.url, data.audio_url, text);
            } else {
                showError(data.error || 'Failed to generate animation.');
            }
        })
        .catch(err => {
            console.error('Error:', err);
            showError('An error occurred while generating the animation.');
        });
    });
});
