document.addEventListener('DOMContentLoaded', function() {
    const promptForm = document.getElementById('promptForm');
    const responseContainer = document.getElementById('responseContainer');
    const responseText = document.getElementById('responseText');
    const errorMessage = document.getElementById('errorMessage');
    const errorText = document.getElementById('errorText');
    const loadingIndicator = document.getElementById('loadingIndicator');
    const initialMessage = document.getElementById('initialMessage');
    const tokenInfo = document.getElementById('tokenInfo');
    const promptTokens = document.getElementById('promptTokens');
    const responseTokens = document.getElementById('responseTokens');
    const totalTokens = document.getElementById('totalTokens');
    
    // Model name mapping
    const modelNames = {
        "anthropic/claude-3-opus-20240229": "Claude 3 Opus",
        "anthropic/claude-3-sonnet-20240229": "Claude 3 Sonnet",
        "anthropic/claude-3-haiku-20240307": "Claude 3 Haiku",
        "openai/gpt-4o": "GPT-4o",
        "openai/gpt-3.5-turbo": "GPT-3.5 Turbo",
        "google/gemini-pro": "Gemini Pro",
        "meta-llama/llama-3-70b-instruct": "Llama 3 70B",
        "deepseek/deepseek-coder": "DeepSeek Coder"
    };
    
    if (promptForm) {
        promptForm.addEventListener('submit', async function(e) {
            e.preventDefault();
            
            const prompt = document.getElementById('prompt').value.trim();
            const model = document.getElementById('model').value;
            const useWebSearch = document.getElementById('useWebSearch').checked;
            const useNewsSearch = document.getElementById('useNewsSearch').checked;
            
            // Input validation
            if (!prompt) {
                showError('Please enter a prompt before submitting.');
                return;
            }
            
            // Show loading indicator
            showLoading();
            hideError();
            
            // Send request to the server
            try {
                const formData = new FormData();
                formData.append('prompt', prompt);
                formData.append('model', model);
                formData.append('use_web_search', useWebSearch);
                formData.append('use_news_search', useNewsSearch);
                
                const response = await fetch('/prompt', {
                    method: 'POST',
                    body: formData
                });
                
                const data = await response.json();
                
                hideLoading();
                
                if (data.success) {
                    showResponse(data.response, data.tokens, prompt);
                } else {
                    showError(data.error || 'An unknown error occurred.');
                }
            } catch (error) {
                hideLoading();
                showError('Failed to communicate with the server. Please try again.');
                console.error('Error:', error);
            }
        });
    }
    
    function showResponse(text, tokens, userPrompt) {
        // Initialize markdown parser
        const md = window.markdownit({
            highlight: function (str, lang) {
                if (lang && hljs.getLanguage(lang)) {
                    try {
                        return hljs.highlight(str, { language: lang }).value;
                    } catch (__) {}
                }
                return ''; // use external default escaping
            }
        });
        
        initialMessage.classList.add('hidden');
        
        // Check for multimedia requests in the original prompt and response
        const lowerPrompt = userPrompt.toLowerCase();
        const lowerText = text.toLowerCase();
        let multimediaBox = '';
        
        // Check if the user is asking for image generation
        if (
            (lowerPrompt.includes('image') && (lowerPrompt.includes('generat') || lowerPrompt.includes('creat'))) ||
            (lowerPrompt.includes('picture') && (lowerPrompt.includes('generat') || lowerPrompt.includes('creat'))) ||
            lowerPrompt.includes('dall-e') || 
            lowerPrompt.includes('midjourney') ||
            lowerPrompt.includes('stable diffusion') ||
            // Response contains references to external image generators
            lowerText.includes('galaxy.ai') || 
            lowerText.includes('imagoria') ||
            (lowerText.includes('image generator') && lowerText.includes('ai'))
        ) {
            multimediaBox = `
            <div class="p-4 mb-4 mt-4 bg-pink-50 border border-pink-200 rounded-md">
                <h4 class="text-pink-800 font-semibold mb-2">📷 Looking to generate images?</h4>
                <p class="text-pink-700 mb-3">Instead of using external tools, our portal has built-in image generation!</p>
                <a href="/image_generator" class="inline-flex items-center px-4 py-2 bg-pink-600 text-white rounded-md hover:bg-pink-700 transition">
                    <i class="fas fa-image mr-2"></i> Use Our Image Generator
                </a>
            </div>`;
        } 
        // Check if the user is asking for video generation
        else if (
            (lowerPrompt.includes('video') && (lowerPrompt.includes('generat') || lowerPrompt.includes('creat'))) ||
            lowerPrompt.includes('animation') || 
            lowerPrompt.includes('movie') ||
            // Response mentions video generation services
            (lowerText.includes('video generator') && lowerText.includes('ai'))
        ) {
            multimediaBox = `
            <div class="p-4 mb-4 mt-4 bg-indigo-50 border border-indigo-200 rounded-md">
                <h4 class="text-indigo-800 font-semibold mb-2">🎬 Looking to generate videos?</h4>
                <p class="text-indigo-700 mb-3">Instead of using external tools, our portal has built-in video generation!</p>
                <a href="/video_generator_page" class="inline-flex items-center px-4 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700 transition">
                    <i class="fas fa-film mr-2"></i> Use Our Video Generator
                </a>
            </div>`;
        } 
        // Check if the user is asking for text-to-speech
        else if (
            (lowerPrompt.includes('audio') && (lowerPrompt.includes('generat') || lowerPrompt.includes('creat'))) ||
            (lowerPrompt.includes('speech') && lowerPrompt.includes('text')) || 
            lowerPrompt.includes('tts') || 
            lowerPrompt.includes('speak') ||
            lowerPrompt.includes('text to speech') ||
            // Response mentions TTS services
            (lowerText.includes('text to speech') && lowerText.includes('service'))
        ) {
            multimediaBox = `
            <div class="p-4 mb-4 mt-4 bg-yellow-50 border border-yellow-200 rounded-md">
                <h4 class="text-yellow-800 font-semibold mb-2">🔊 Looking to convert text to speech?</h4>
                <p class="text-yellow-700 mb-3">Instead of using external tools, our portal has built-in text-to-speech!</p>
                <a href="/text_to_speech_page" class="inline-flex items-center px-4 py-2 bg-yellow-600 text-white rounded-md hover:bg-yellow-700 transition">
                    <i class="fas fa-volume-up mr-2"></i> Use Our Text-to-Speech
                </a>
            </div>`;
        }
        
        // Add multimedia box if relevant
        responseText.innerHTML = md.render(text) + multimediaBox;
        responseText.classList.remove('hidden');
        
        // Add token info display if available
        if (tokens) {
            promptTokens.textContent = tokens.prompt;
            responseTokens.textContent = tokens.response;
            totalTokens.textContent = tokens.total;
            tokenInfo.classList.remove('hidden');
        }
        
        // Highlight code blocks
        document.querySelectorAll('pre code').forEach((block) => {
            hljs.highlightBlock(block);
        });
    }
    
    function showError(text) {
        errorText.textContent = text;
        errorMessage.classList.remove('hidden');
    }
    
    function hideError() {
        errorMessage.classList.add('hidden');
    }
    
    function showLoading() {
        initialMessage.classList.add('hidden');
        responseText.classList.add('hidden');
        loadingIndicator.classList.remove('hidden');
    }
    
    function hideLoading() {
        loadingIndicator.classList.add('hidden');
    }
});
