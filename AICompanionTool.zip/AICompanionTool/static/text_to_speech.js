document.addEventListener('DOMContentLoaded', function() {
    const ttsForm = document.getElementById('tts-form');
    const textInput = document.getElementById('text');
    const languageSelect = document.getElementById('language');
    const resultContainer = document.getElementById('result-container');
    const loadingDiv = document.getElementById('loading');
    const audioResult = document.getElementById('audio-result');
    const audioContainer = document.getElementById('audio-container');
    const audioText = document.getElementById('audio-text');
    const downloadLink = document.getElementById('download-link');
    const errorContainer = document.getElementById('error-container');
    const errorMessage = document.getElementById('error-message');
    const getNewsBtn = document.getElementById('get-news-btn');

    // Function to show loading state
    function showLoading() {
        resultContainer.classList.remove('hidden');
        loadingDiv.classList.remove('hidden');
        audioResult.classList.add('hidden');
        errorContainer.classList.add('hidden');
    }

    // Function to hide loading state
    function hideLoading() {
        loadingDiv.classList.add('hidden');
    }

    // Function to display error
    function showError(message) {
        errorContainer.classList.remove('hidden');
        errorMessage.textContent = message;
        resultContainer.classList.add('hidden');
    }

    // Function to display audio result
    function showAudioResult(audioUrl, text) {
        hideLoading();
        audioResult.classList.remove('hidden');
        
        // Create audio element
        audioContainer.innerHTML = `
            <audio controls class="w-full max-w-md">
                <source src="${audioUrl}" type="audio/mpeg">
                Your browser does not support the audio element.
            </audio>
        `;
        
        // Set text display
        audioText.textContent = text;
        
        // Set download link
        downloadLink.href = audioUrl;
        downloadLink.download = 'audio_' + new Date().getTime() + '.mp3';
    }

    // Handle form submission
    ttsForm.addEventListener('submit', function(e) {
        e.preventDefault();
        
        const text = textInput.value.trim();
        const language = languageSelect.value;
        
        if (!text) {
            showError('Please enter some text to convert to speech.');
            return;
        }
        
        showLoading();
        
        // Send request to server
        fetch('/api/text-to-speech', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                text: text,
                language: language
            }),
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                showAudioResult(data.url, text);
            } else {
                showError(data.error || 'Failed to generate audio.');
            }
        })
        .catch(err => {
            console.error('Error:', err);
            showError('An error occurred while generating the audio.');
        });
    });

    // Handle fetch news button click
    if (getNewsBtn) {
        getNewsBtn.addEventListener('click', function() {
            getNewsBtn.disabled = true;
            getNewsBtn.innerHTML = '<i class="fas fa-spinner fa-spin mr-2"></i>Fetching...';
            
            fetch('/api/news')
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    textInput.value = data.headlines;
                } else {
                    showError(data.error || 'Failed to fetch news.');
                }
            })
            .catch(err => {
                console.error('Error:', err);
                showError('An error occurred while fetching the news.');
            })
            .finally(() => {
                getNewsBtn.disabled = false;
                getNewsBtn.innerHTML = '<i class="fas fa-newspaper mr-2"></i>Fetch Latest Headlines';
            });
        });
    }
});
