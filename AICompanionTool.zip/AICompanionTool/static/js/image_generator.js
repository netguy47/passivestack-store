// Image Generator Client-side JavaScript
document.addEventListener('DOMContentLoaded', function() {
    const form = document.getElementById('image-form');
    const prompt = document.getElementById('prompt');
    const submitButton = document.getElementById('submit-button');
    const resultContainer = document.getElementById('result');
    const errorContainer = document.getElementById('error');
    const loadingIndicator = document.getElementById('loading');
    
    if (form) {
        form.addEventListener('submit', function(e) {
            e.preventDefault();
            
            // Validate input
            if (!prompt.value.trim()) {
                showError('Please enter a prompt to generate an image.');
                return;
            }
            
            // Show loading state
            showLoading();
            hideError();
            
            // Submit form data via AJAX
            fetch('/text_to_image', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: new URLSearchParams({
                    'prompt': prompt.value,
                    'model': 'openai/gpt-4o'  // Default model
                })
            })
            .then(response => response.json())
            .then(data => {
                hideLoading();
                
                if (data.success) {
                    showImageResult(data.url, prompt.value);
                } else {
                    showError(data.error || 'An error occurred while generating the image.');
                }
            })
            .catch(error => {
                hideLoading();
                showError('Error: ' + error.message);
                console.error('Error:', error);
            });
        });
    }
    
    function showImageResult(imageUrl, promptText) {
        // Clear previous results
        resultContainer.innerHTML = '';
        
        // Create image display
        const resultCard = document.createElement('div');
        resultCard.className = 'bg-slate-800 p-4 rounded-lg shadow-lg mb-4';
        
        // Image container
        const imageContainer = document.createElement('div');
        imageContainer.className = 'mb-3';
        
        // Create image element
        const image = document.createElement('img');
        image.src = imageUrl;
        image.alt = 'Generated image';
        image.className = 'w-full max-h-96 object-contain rounded';
        
        // Add prompt text
        const promptElement = document.createElement('div');
        promptElement.className = 'text-sm text-gray-300 mt-2';
        promptElement.textContent = `Prompt: ${promptText}`;
        
        // Assemble the components
        imageContainer.appendChild(image);
        resultCard.appendChild(imageContainer);
        resultCard.appendChild(promptElement);
        resultContainer.appendChild(resultCard);
        
        // Add download button
        const downloadLink = document.createElement('a');
        downloadLink.href = imageUrl;
        downloadLink.download = 'generated-image.png';
        downloadLink.className = 'block bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded text-center mt-2';
        downloadLink.textContent = 'Download Image';
        resultContainer.appendChild(downloadLink);
        
        // Show the result container
        resultContainer.style.display = 'block';
    }
    
    function showError(text) {
        errorContainer.textContent = text;
        errorContainer.style.display = 'block';
    }
    
    function hideError() {
        errorContainer.textContent = '';
        errorContainer.style.display = 'none';
    }
    
    function showLoading() {
        loadingIndicator.style.display = 'flex';
        if (submitButton) submitButton.disabled = true;
    }
    
    function hideLoading() {
        loadingIndicator.style.display = 'none';
        if (submitButton) submitButton.disabled = false;
    }
});